package net.javaforge.jqwicket.ui.liscroll;

import net.javaforge.jqwicket.IJQWidget;

/**
 * 
 * @author cschaedel
 */
public interface ILiScroll extends IJQWidget<LiScrollOptions> {

	static final CharSequence JQ_COMPONENT_NAME = "liScroll";
	
}
