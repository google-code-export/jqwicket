package com.google.code.jqwicket.ui.liscroll;

import com.google.code.jqwicket.IJQWidget;

/**
 * 
 * @author cschaedel
 */
public interface ILiScroll extends IJQWidget<LiScrollOptions> {

	static final CharSequence JQ_COMPONENT_NAME = "liScroll";
	
}
